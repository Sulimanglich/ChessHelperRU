package com.example.chesshelper

import kotlin.math.abs

class Move(val from: Int, val to: Int)

/** Простой движок: поиск alpha-beta на 3 хода, без рокировки и взятия на проходе. Доска: 64 символа, индекс 0 = a8. */
object Engine {
    private val KN = arrayOf(intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(-1, 2), intArrayOf(-2, 1), intArrayOf(1, -2), intArrayOf(2, -1), intArrayOf(-1, -2), intArrayOf(-2, -1))
    private val KG = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1), intArrayOf(1, 1), intArrayOf(1, -1), intArrayOf(-1, 1), intArrayOf(-1, -1))

    fun name(i: Int): String = "abcdefgh"[i % 8].toString() + (8 - i / 8)
    private fun v(c: Char): Int = when (c.lowercaseChar()) { 'p' -> 100; 'n' -> 320; 'b' -> 330; 'r' -> 500; 'q' -> 900; else -> 0 }

    fun pseudo(b: CharArray, white: Boolean): ArrayList<Move> {
        val m = ArrayList<Move>()
        for (i in 0 until 64) {
            val p = b[i]
            if (p == '.' || p.isUpperCase() != white) continue
            val r = i / 8
            val c = i % 8
            val t = p.lowercaseChar()
            when (t) {
                'p' -> {
                    val d = if (white) -1 else 1
                    val st = if (white) 6 else 1
                    if (r + d in 0..7 && b[(r + d) * 8 + c] == '.') {
                        m.add(Move(i, (r + d) * 8 + c))
                        if (r == st && b[(r + 2 * d) * 8 + c] == '.') m.add(Move(i, (r + 2 * d) * 8 + c))
                    }
                    for (dc in intArrayOf(-1, 1)) {
                        val rr = r + d
                        val cc = c + dc
                        if (rr in 0..7 && cc in 0..7 && b[rr * 8 + cc] != '.' && b[rr * 8 + cc].isUpperCase() != white) m.add(Move(i, rr * 8 + cc))
                    }
                }
                'n', 'k' -> {
                    for (o in (if (t == 'n') KN else KG)) {
                        val rr = r + o[0]
                        val cc = c + o[1]
                        if (rr in 0..7 && cc in 0..7 && (b[rr * 8 + cc] == '.' || b[rr * 8 + cc].isUpperCase() != white)) m.add(Move(i, rr * 8 + cc))
                    }
                }
                else -> {
                    for (o in KG) {
                        val diag = o[0] != 0 && o[1] != 0
                        if ((t == 'b' && !diag) || (t == 'r' && diag)) continue
                        var rr = r + o[0]
                        var cc = c + o[1]
                        while (rr in 0..7 && cc in 0..7) {
                            val q = b[rr * 8 + cc]
                            if (q == '.') {
                                m.add(Move(i, rr * 8 + cc))
                            } else {
                                if (q.isUpperCase() != white) m.add(Move(i, rr * 8 + cc))
                                break
                            }
                            rr += o[0]
                            cc += o[1]
                        }
                    }
                }
            }
        }
        return m
    }

    fun apply(b: CharArray, m: Move): CharArray {
        val n = b.copyOf()
        var p = n[m.from]
        if (p == 'P' && m.to < 8) p = 'Q'
        if (p == 'p' && m.to >= 56) p = 'q'
        n[m.to] = p
        n[m.from] = '.'
        return n
    }

    fun inCheck(b: CharArray, white: Boolean): Boolean {
        val k = b.indexOf(if (white) 'K' else 'k')
        if (k < 0) return true
        return pseudo(b, !white).any { it.to == k }
    }

    fun legal(b: CharArray, white: Boolean): List<Move> = pseudo(b, white).filter { !inCheck(apply(b, it), white) }

    private fun eval(b: CharArray): Int {
        var s = 0
        for (i in 0 until 64) {
            val p = b[i]
            if (p == '.') continue
            val r = i / 8
            val c = i % 8
            var x = v(p)
            if (p.lowercaseChar() == 'p') x += (if (p.isUpperCase()) 6 - r else r - 1) * 6
            if (p.lowercaseChar() == 'n' || p.lowercaseChar() == 'b') x += (3 - maxOf(abs(2 * c - 7), abs(2 * r - 7)) / 2) * 4
            s += if (p.isUpperCase()) x else -x
        }
        return s
    }

    private fun order(b: CharArray, ms: List<Move>) =
        ms.sortedByDescending { if (b[it.to] != '.') v(b[it.to]) * 10 - v(b[it.from]) else 0 }

    private fun search(b: CharArray, white: Boolean, d: Int, alpha: Int, beta: Int): Int {
        if (d == 0) return (if (white) 1 else -1) * eval(b)
        val ms = legal(b, white)
        if (ms.isEmpty()) return if (inCheck(b, white)) -100000 - d else 0
        var a = alpha
        for (m in order(b, ms)) {
            val s = -search(apply(b, m), !white, d - 1, -beta, -a)
            if (s >= beta) return s
            if (s > a) a = s
        }
        return a
    }

    fun best(b: CharArray, white: Boolean, depth: Int = 3): Move? {
        var bm: Move? = null
        var bs = -1000000
        for (m in order(b, legal(b, white))) {
            val s = -search(apply(b, m), !white, depth - 1, -1000000, -bs)
            if (bm == null || s > bs) { bs = s; bm = m }
        }
        return bm
    }
}
