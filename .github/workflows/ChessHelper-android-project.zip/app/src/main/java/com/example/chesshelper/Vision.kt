package com.example.chesshelper

import android.content.Context
import android.graphics.Bitmap
import kotlin.math.abs

/** Распознавание доски по скриншоту: поиск доски, затем сравнение контуров фигур с образцами из начальной позиции. */
object Vision {
    private const val G = 24
    private const val MIN_EDGES = 20
    private const val START = "rnbqkbnrpppppppp................................PPPPPPPPRNBQKBNR"

    class Feat(val edges: BooleanArray, val center: Float, val count: Int)
    class Templ(val white: Boolean, val type: Char, val bits: BooleanArray)

    var templates = listOf<Templ>()
    var thr = 150f

    private fun lum(p: Int) = ((p shr 16 and 255) * 30 + (p shr 8 and 255) * 59 + (p and 255) * 11) / 100
    private fun diff(a: Int, b: Int) = abs((a shr 16 and 255) - (b shr 16 and 255)) + abs((a shr 8 and 255) - (b shr 8 and 255)) + abs((a and 255) - (b and 255))
    private fun std(i: Int, whiteBottom: Boolean) = if (whiteBottom) i else 63 - i

    fun pixels(bmp: Bitmap): IntArray {
        val p = IntArray(bmp.width * bmp.height)
        bmp.getPixels(p, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        return p
    }

    /** Доска считается занимающей всю ширину экрана. Возвращает y верхнего края или -1. */
    fun findBoard(px: IntArray, w: Int, h: Int): Int {
        val s = w / 8
        val off = maxOf(4, s / 12)
        if (h < 8 * s) return -1
        var best = -1
        val ys = ArrayList<Int>()
        for (y in 0..(h - 8 * s)) {
            fun p(r: Int, c: Int) = px[(y + r * s + s - off) * w + c * s + off]
            val a = p(0, 0)
            val b = p(0, 1)
            if (diff(a, b) < 40) continue
            var sc = 0
            for (r in 0 until 8) for (c in 0 until 8) if (diff(p(r, c), if ((r + c) % 2 == 0) a else b) < 24) sc++
            if (sc > best) { best = sc; ys.clear() }
            if (sc == best) ys.add(y)
        }
        return if (best >= 50 && ys.isNotEmpty()) ys[ys.size / 2] else -1
    }

    fun feats(px: IntArray, w: Int, top: Int): List<Feat> {
        val s = w / 8
        val out = ArrayList<Feat>()
        for (r in 0 until 8) for (c in 0 until 8) out.add(feat(px, w, c * s, top + r * s, s))
        return out
    }

    private fun feat(px: IntArray, w: Int, x0: Int, y0: Int, s: Int): Feat {
        val m = s / 10
        val inner = s - 2 * m
        val l = FloatArray(G * G)
        for (gy in 0 until G) for (gx in 0 until G) {
            val xa = x0 + m + gx * inner / G
            val xb = maxOf(xa + 1, x0 + m + (gx + 1) * inner / G)
            val ya = y0 + m + gy * inner / G
            val yb = maxOf(ya + 1, y0 + m + (gy + 1) * inner / G)
            var sum = 0
            var n = 0
            for (y in ya until yb) for (x in xa until xb) { sum += lum(px[y * w + x]); n++ }
            l[gy * G + gx] = sum.toFloat() / n
        }
        val e = BooleanArray(G * G)
        var cnt = 0
        for (gy in 1 until G - 1) for (gx in 1 until G - 1) {
            val dx = l[gy * G + gx + 1] - l[gy * G + gx - 1]
            val dy = l[(gy + 1) * G + gx] - l[(gy - 1) * G + gx]
            if (abs(dx) + abs(dy) > 40) { e[gy * G + gx] = true; cnt++ }
        }
        var cs = 0f
        var cn = 0
        for (gy in G / 3 until 2 * G / 3) for (gx in G / 3 until 2 * G / 3) { cs += l[gy * G + gx]; cn++ }
        return Feat(e, cs / cn, cnt)
    }

    /** Калибровка по начальной позиции (допускается один сделанный ход). */
    fun calibrate(f: List<Feat>, whiteBottom: Boolean, ctx: Context): Boolean {
        val t = ArrayList<Templ>()
        var ws = 0f; var wn = 0; var bs = 0f; var bn = 0; var bad = 0
        for (i in 0 until 64) {
            val ch = START[std(i, whiteBottom)]
            val has = f[i].count >= MIN_EDGES
            if (has != (ch != '.')) { bad++; continue }
            if (ch == '.') continue
            val w = ch.isUpperCase()
            t.add(Templ(w, ch.lowercaseChar(), f[i].edges))
            if (w) { ws += f[i].center; wn++ } else { bs += f[i].center; bn++ }
        }
        if (bad > 2 || wn < 8 || bn < 8) return false
        templates = t
        thr = (ws / wn + bs / bn) / 2
        save(ctx)
        return true
    }

    fun read(f: List<Feat>, whiteBottom: Boolean): CharArray? {
        if (templates.isEmpty()) return null
        val b = CharArray(64) { '.' }
        for (i in 0 until 64) {
            val ft = f[i]
            if (ft.count < MIN_EDGES) continue
            val w = ft.center > thr
            var bt = 'p'
            var bd = Int.MAX_VALUE
            for (t in templates) if (t.white == w) {
                var d = 0
                for (k in 0 until G * G) if (t.bits[k] != ft.edges[k]) d++
                if (d < bd) { bd = d; bt = t.type }
            }
            b[std(i, whiteBottom)] = if (w) bt.uppercaseChar() else bt
        }
        return b
    }

    private fun save(ctx: Context) {
        val s = templates.joinToString(";") { t ->
            (if (t.white) "1" else "0") + t.type + t.bits.joinToString("") { if (it) "1" else "0" }
        }
        ctx.getSharedPreferences("v", 0).edit().putString("t", s).putFloat("thr", thr).apply()
    }

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("v", 0)
        val s = p.getString("t", null) ?: return
        thr = p.getFloat("thr", 150f)
        templates = s.split(";").map { x -> Templ(x[0] == '1', x[1], BooleanArray(G * G) { k -> x[2 + k] == '1' }) }
    }
}
