package com.example.chesshelper

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        l.addView(TextView(this).apply {
            textSize = 16f
            text = "Помощник: шахматы\n\n1. Разрешите показ поверх других приложений.\n" +
                "2. Нажмите «Запустить» и разрешите запись экрана.\n" +
                "3. Откройте партию. Начальная позиция: нажмите 📐 (калибровка), один раз.\n" +
                "4. 💡 — показать лучший ход стрелкой. ⚪/⚫ — ваш цвет (внизу доски). ✥ — перетащить панель, ✕ — выход.\n\n" +
                "Доска должна занимать всю ширину экрана. Не используйте в рейтинговых партиях: это запрещено правилами."
        })
        l.addView(Button(this).apply {
            text = "1. Разрешить поверх других приложений"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
            }
        })
        l.addView(Button(this).apply {
            text = "2. Запустить помощник"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Сначала шаг 1", Toast.LENGTH_SHORT).show()
                } else {
                    val mpm = getSystemService(MediaProjectionManager::class.java)
                    startActivityForResult(mpm.createScreenCaptureIntent(), 1)
                }
            }
        })
        setContentView(l)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 2)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 1 && res == RESULT_OK && d != null) {
            startForegroundService(Intent(this, OverlayService::class.java).putExtra("code", res).putExtra("data", d))
            moveTaskToBack(true)
        }
    }
}
