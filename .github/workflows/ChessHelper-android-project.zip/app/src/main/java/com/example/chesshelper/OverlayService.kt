package com.example.chesshelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class ArrowView(c: Context) : View(c) {
    var a: PointF? = null
    var b: PointF? = null
    var sq = 100f
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC1E78FF.toInt(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC1E78FF.toInt() }

    override fun onDraw(cv: Canvas) {
        val s = a ?: return
        val e = b ?: return
        line.strokeWidth = sq / 7
        val dx = e.x - s.x
        val dy = e.y - s.y
        val len = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (len < 1f) return
        val ux = dx / len
        val uy = dy / len
        val head = sq * 0.45f
        cv.drawLine(s.x, s.y, e.x - ux * head * 0.6f, e.y - uy * head * 0.6f, line)
        val p = Path()
        p.moveTo(e.x, e.y)
        p.lineTo(e.x - ux * head - uy * head * 0.55f, e.y - uy * head + ux * head * 0.55f)
        p.lineTo(e.x - ux * head + uy * head * 0.55f, e.y - uy * head - ux * head * 0.55f)
        p.close()
        cv.drawPath(p, fill)
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private val ex = Executors.newSingleThreadExecutor()
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var rd: ImageReader? = null
    private var latest: Image? = null
    private var panel: LinearLayout? = null
    private var arrow: ArrowView? = null
    private var colorBtn: TextView? = null
    private var whiteBottom = true

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (proj != null || i == null) return START_NOT_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("c", "Помощник", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "c").setContentTitle("Помощник работает").setSmallIcon(android.R.drawable.ic_menu_compass).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(1, n)
        @Suppress("DEPRECATION")
        val data = i.getParcelableExtra<Intent>("data")
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(i.getIntExtra("code", 0), data!!)
        proj = p
        p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
        wm = getSystemService(WindowManager::class.java)
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        val reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 3)
        rd = reader
        reader.setOnImageAvailableListener({ r ->
            val im = r.acquireLatestImage()
            if (im != null) { latest?.close(); latest = im }
        }, h)
        vd = p.createVirtualDisplay("cap", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, null)
        Vision.load(this)
        buildUi()
        return START_NOT_STICKY
    }

    private fun params(touchable: Boolean): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE)
        val size = if (touchable) WindowManager.LayoutParams.WRAP_CONTENT else WindowManager.LayoutParams.MATCH_PARENT
        return WindowManager.LayoutParams(size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, lp, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun tv(t: String, click: (() -> Unit)?): TextView = TextView(this).apply {
        text = t; textSize = 22f; setPadding(30, 18, 30, 18); setTextColor(Color.WHITE); gravity = Gravity.CENTER
        if (click != null) setOnClickListener { click() }
    }

    private fun buildUi() {
        val av = ArrowView(this)
        arrow = av
        wm.addView(av, params(false))
        val p = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xAA000000.toInt()) }
        val lp = params(true)
        lp.x = 20
        lp.y = 300
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        val drag = tv("✥", null)
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(p, lp) }
            }
            true
        }
        val cb = tv("⚪") {
            whiteBottom = !whiteBottom
            colorBtn?.text = if (whiteBottom) "⚪" else "⚫"
            toast(if (whiteBottom) "Вы играете белыми (белые внизу)" else "Вы играете чёрными (чёрные внизу)")
        }
        colorBtn = cb
        p.addView(drag)
        p.addView(tv("💡") { hint() })
        p.addView(tv("📐") { calib() })
        p.addView(cb)
        p.addView(tv("✕") { stopSelf() })
        wm.addView(p, lp)
        panel = p
    }

    private fun toast(s: String) { h.post { Toast.makeText(this, s, Toast.LENGTH_LONG).show() } }

    private fun capture(cb: (IntArray, Int, Int) -> Unit) {
        arrow?.a = null
        arrow?.invalidate()
        h.postDelayed({
            val im = latest
            if (im == null) { toast("Нет кадра, попробуйте ещё раз"); return@postDelayed }
            val pl = im.planes[0]
            pl.buffer.rewind()
            val w = im.width
            val hh = im.height
            val rowPad = pl.rowStride - pl.pixelStride * w
            val bm = Bitmap.createBitmap(w + rowPad / pl.pixelStride, hh, Bitmap.Config.ARGB_8888)
            bm.copyPixelsFromBuffer(pl.buffer)
            val px = Vision.pixels(Bitmap.createBitmap(bm, 0, 0, w, hh))
            bm.recycle()
            ex.execute {
                try { cb(px, w, hh) } catch (e: Exception) { toast("Ошибка: " + e.message) }
            }
        }, 250)
    }

    private fun calib() = capture { px, w, hh ->
        val top = Vision.findBoard(px, w, hh)
        if (top < 0) { toast("Доска не найдена"); return@capture }
        val ok = Vision.calibrate(Vision.feats(px, w, top), whiteBottom, this)
        toast(if (ok) "Калибровка готова" else "Нужна начальная позиция без стрелок и подсветки. Проверьте цвет ⚪/⚫")
    }

    private fun hint() = capture { px, w, hh ->
        val top = Vision.findBoard(px, w, hh)
        if (top < 0) { toast("Доска не найдена"); return@capture }
        val pos = Vision.read(Vision.feats(px, w, top), whiteBottom)
        if (pos == null) { toast("Сначала калибровка (📐) в начальной позиции"); return@capture }
        if (!pos.contains('K') || !pos.contains('k')) { toast("Позиция не распознана"); return@capture }
        val m = Engine.best(pos, whiteBottom)
        if (m == null) { toast("Нет ходов"); return@capture }
        val s = w / 8f
        fun pt(i: Int): PointF {
            val r = if (whiteBottom) i / 8 else 7 - i / 8
            val c = if (whiteBottom) i % 8 else 7 - i % 8
            return PointF(c * s + s / 2, top + r * s + s / 2)
        }
        h.post { arrow?.sq = s; arrow?.a = pt(m.from); arrow?.b = pt(m.to); arrow?.invalidate() }
        toast("Ход: " + Engine.name(m.from) + " → " + Engine.name(m.to))
        h.postDelayed({ arrow?.a = null; arrow?.invalidate() }, 8000)
    }

    override fun onDestroy() {
        try { arrow?.let { wm.removeView(it) }; panel?.let { wm.removeView(it) } } catch (e: Exception) {}
        vd?.release(); latest?.close(); rd?.close(); proj?.stop()
        super.onDestroy()
    }
}
